# -*- coding: utf-8 -*-

import os
import sys
import math
reload(sys)
sys.setdefaultencoding('utf-8')


# Исходные данные
Mstart = 4350  # Масса КА
Mka = Mstart
Mfuel = 0
Msbb = 100  # Масса сбрасываемого блока баков, если таковой есть. Если нет, поставить 0
Madapter = 80  # Масса адаптера КА-РБ
Mlgm = 950  # Масса КА сухого, включая адаптер КА-РБ

# Коэффициенты запаса по топливу по этапам полёта
Kf1 = 1.5
Kf2 = 1.07

# Усреднённые импульсы по этапам полёта
Isp1 = 327
Isp2 = 220
Isp3 = 320


# Расчёт
try:
	print u'Стартовая масса:', Mstart, u' ( без адаптера:', Mstart - Madapter, u')\n'
	Mstart = Mstart - Madapter

	V = 38
	Isp = Isp1
	Kf = Kf1
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'1) 1-я коррекция на перелёте.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 10
	Isp = Isp2
	Kf = Kf1
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'2) 2-я коррекция на перелёте.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 850
	Isp = Isp3
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2) - Msbb
	print u'3) 1-е торможение и выход на ОИСЛ. Сброс СББ (если есть).\n   └ Скорость:', V, u'  уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 20
	Isp = Isp2
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'4) 3-я коррекция.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 20
	Isp = Isp3
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'5) 4-я коррекция.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 1150
	Isp = Isp3
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'6) 2-е торможение.\n   └ Скорость:', V, u' уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 22
	Isp = Isp3
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'7) Предварительное торможение.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'

	V = 94
	Isp = Isp3
	Kf = Kf2
	Mt = Mstart * ( 1 - math.exp((-V) / (9.81 * Isp)) ) * Kf
	Mfuel = Mfuel + round(Mt, 2)
	Mstart = Mstart - round(Mt, 2)
	print u'8) Манёвр увода.\n   └ Скорость:', V, u'   уд. импульс:', Isp, u'  треб. топлива:', round(Mt, 2), u'(резерв', (Kf - 1)*100, '%)'
except:
	print u'\nВозникла какая-то ошибка.'


Mfuel = round(Mfuel)
Mfuelsbb = round(Mfuel * 0.42)
Mfuelbaki = Mfuel - Mfuelsbb
print u'\nИтого топлива, кг:', Mfuel, u'\n  └ Из них СББ:', Mfuelsbb, u', основных баков:', Mfuelbaki

print u'Масса КА на поверхности, кг:', Mka - Mfuel - Madapter - Msbb

Mpn = Mka - Mlgm - Mfuel
print u'Масса ПН, кг:', Mpn


input()
